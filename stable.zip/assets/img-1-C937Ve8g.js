const a="/assets/img-1-DlR3_OtN.jpg";export{a};
